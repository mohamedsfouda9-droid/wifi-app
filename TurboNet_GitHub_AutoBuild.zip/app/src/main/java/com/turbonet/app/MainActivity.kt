package com.turbonet.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var testButton: Button
    private val bg = 0xFFDDF4FF.toInt()
    private val panel = 0xBFFFFFFF.toInt()
    private val cyan = 0xFF168DE2.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(bg)
        }
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(content)
        page.addView(scroller, ViewGroup.LayoutParams(-1, -1))

        content.addView(label("TURBO NET", 30, 0xFF0877C9.toInt(), true))
        content.addView(label("تحسين الاتصال وتسريع التحميل", 17, 0xFF123B5A.toInt(), true))
        content.addView(space(18))
        status = label("جارٍ فحص حالة الشبكة…", 16, 0xFF234C69.toInt(), false)
        status.setPadding(16, 20, 16, 20)
        status.setBackgroundColor(panel)
        content.addView(status, matchWrap())
        content.addView(space(16))

        testButton = button("اختبار سرعة التنزيل")
        testButton.setOnClickListener { runSpeedTest() }
        content.addView(testButton, matchWrap())
        result = label("اضغط على الزر لقياس سرعة التنزيل التقريبية.", 18, 0xFF123B5A.toInt(), true)
        result.gravity = Gravity.CENTER
        result.setPadding(12, 24, 12, 24)
        content.addView(result, matchWrap())
        content.addView(space(10))

        content.addView(label("مدير تحميل الملفات", 21, cyan, true))
        content.addView(label("الصق رابط ملف مباشر يبدأ بـ https://", 14, 0xFF234C69.toInt(), false))
        val urlInput = EditText(this).apply {
            hint = "https://example.com/file.zip"
            setHintTextColor(0xFF6C91AA.toInt())
            setTextColor(0xFF123B5A.toInt())
            setSingleLine(true)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }
        content.addView(urlInput, matchWrap())
        content.addView(space(10))
        val downloadButton = button("تنزيل الملف")
        downloadButton.setOnClickListener {
            val raw = urlInput.text.toString().trim()
            if (!raw.startsWith("https://", true) && !raw.startsWith("http://", true)) {
                Toast.makeText(this, "أدخل رابط تحميل صحيح يبدأ بـ https://", Toast.LENGTH_LONG).show()
            } else {
                try {
                    val req = DownloadManager.Request(Uri.parse(raw))
                        .setTitle("Turbo Net - تنزيل ملف")
                        .setDescription("يتم التنزيل باستخدام مدير التنزيلات في أندرويد")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setAllowedOverMetered(true)
                        .setAllowedOverRoaming(false)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName(raw))
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                    Toast.makeText(this, "بدأ التنزيل. تابع الإشعار لمعرفة التقدم.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر بدء التنزيل: تحقق من الرابط.", Toast.LENGTH_LONG).show()
                }
            }
        }
        content.addView(downloadButton, matchWrap())
        content.addView(space(18))
        content.addView(label("معلومة مهمة", 18, cyan, true))
        content.addView(label("التطبيق يقيس سرعة الاتصال ويستخدم مدير تنزيلات أندرويد. لا يستطيع تجاوز حدود الباقة أو تقوية إشارة الشبكة ماديًا. نتيجة الاختبار تعتمد على الخادم وحالة الشبكة.", 14, 0xFF234C69.toInt(), false))
        setContentView(page)
        updateNetworkStatus()
    }

    private fun updateNetworkStatus() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(network)
        val text = when {
            caps == null -> "حالة الشبكة: لا يوجد اتصال بالإنترنت"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "حالة الشبكة: متصل عبر Wi‑Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "حالة الشبكة: متصل ببيانات الهاتف"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "حالة الشبكة: اتصال سلكي"
            else -> "حالة الشبكة: اتصال متاح"
        }
        status.text = text
    }

    private fun runSpeedTest() {
        testButton.isEnabled = false
        result.text = "جارٍ قياس سرعة التنزيل…"
        thread {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://speed.cloudflare.com/__down?bytes=10000000")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 20000
                    setRequestProperty("Cache-Control", "no-cache")
                }
                val start = System.nanoTime()
                var total = 0L
                conn.inputStream.use { input ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                    }
                }
                val seconds = ((System.nanoTime() - start) / 1_000_000_000.0).coerceAtLeast(0.001)
                val mbps = total * 8.0 / seconds / 1_000_000.0
                runOnUiThread {
                    result.text = String.format(java.util.Locale.US,
                        "سرعة التنزيل التقريبية\n%.2f Mbps\n\nحجم البيانات: %.2f MB\nالوقت: %.1f ثانية",
                        mbps, total / 1_000_000.0, seconds)
                    testButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "تعذر إجراء الاختبار. تحقق من الإنترنت ثم حاول مرة أخرى."
                    testButton.isEnabled = true
                }
            } finally {
                conn?.disconnect()
            }
        }
    }

    private fun fileName(raw: String): String {
        val path = Uri.parse(raw).lastPathSegment?.takeIf { it.isNotBlank() } ?: "download.bin"
        return path.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 5, 0, 5)
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        setTextColor(bg)
        setBackgroundColor(cyan)
        textSize = 16f
        isAllCaps = false
    }

    private fun space(dp: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, (dp * resources.displayMetrics.density).toInt())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = (8 * resources.displayMetrics.density).toInt()
    }
}
